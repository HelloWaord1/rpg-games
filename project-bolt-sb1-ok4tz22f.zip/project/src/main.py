import logging
import os
from dotenv import load_dotenv
from langchain_experimental.text_splitter import SemanticChunker
from .bot import TelegramBot
from .config import TelegramConfig
from .session import TelegramSession
from .messages_handler import MessagesHandler
from .ai_service import AIService

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def main():
    try:
        # Load environment variables
        load_dotenv()
        
        # Initialize configuration
        config = TelegramConfig(
            api_id=os.getenv("TELEGRAM_API_ID"),
            api_hash=os.getenv("TELEGRAM_API_HASH"),
            bot_token=os.getenv("TELEGRAM_BOT_TOKEN"),
            session_name="telegram_bot",
            allowed_users=[int(id) for id in os.getenv("ALLOWED_USERS", "").split(",") if id],
            whitelist_enabled=os.getenv("WHITELIST_ENABLED", "false").lower() == "true"
        )

        # Initialize components
        session = TelegramSession(
            api_id=config.api_id,
            api_hash=config.api_hash,
            bot_token=config.bot_token,
            session_name=config.session_name
        )

        text_splitter = SemanticChunker()
        
        messages_handler = MessagesHandler(
            session=session,
            config=config,
            text_splitter=text_splitter,
            logger=logger
        )

        ai_service = AIService(
            api_key=os.getenv("OPENAI_API_KEY"),
            model=os.getenv("OPENAI_MODEL", "gpt-3.5-turbo"),
            temperature=float(os.getenv("OPENAI_TEMPERATURE", "0.7")),
            max_tokens=int(os.getenv("OPENAI_MAX_TOKENS", "150"))
        )

        # Initialize and start the bot
        bot = TelegramBot(
            session=session,
            config=config,
            messages_handler=messages_handler,
            ai_service=ai_service,
            logger=logger
        )

        # Run the bot
        import asyncio
        asyncio.run(bot.start())

    except Exception as e:
        logger.error(f"Error starting the application: {str(e)}", exc_info=True)
        raise

if __name__ == "__main__":
    main()