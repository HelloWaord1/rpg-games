import logging
from telethon import TelegramClient, events
from .messages_handler import MessagesHandler
from .config import TelegramConfig
from .session import TelegramSession
from .ai_service import AIService

class TelegramBot:
    def __init__(
        self,
        session: TelegramSession,
        config: TelegramConfig,
        messages_handler: MessagesHandler,
        ai_service: AIService,
        logger=None
    ):
        self.session = session
        self.config = config
        self.messages_handler = messages_handler
        self.ai_service = ai_service
        self.logger = logger or logging.getLogger(__name__)

    async def start(self):
        try:
            # Register message handler
            @self.session.on(events.NewMessage(pattern=None))
            async def handle_message(event):
                try:
                    # Ignore messages from bots or channels
                    if event.message.from_id is None:
                        return

                    user_id = event.message.from_id.user_id
                    
                    # Check if user is allowed (if whitelist is enabled)
                    if self.config.whitelist_enabled and user_id not in self.config.allowed_users:
                        self.logger.info(f"Ignored message from non-whitelisted user {user_id}")
                        return

                    # Get the message text
                    message_text = event.message.text
                    if not message_text:
                        return

                    self.logger.info(f"Received message from user {user_id}: {message_text}")

                    # Generate AI response
                    ai_response = await self.ai_service.generate_response(message_text)
                    
                    # Send response with simulated typing
                    async for chunk in self.messages_handler.simulate_conversation(ai_response, event.chat_id):
                        await event.respond(chunk)

                except Exception as e:
                    self.logger.error(f"Error handling message: {str(e)}", exc_info=True)
                    await event.respond("Sorry, I encountered an error processing your message.")

            # Start the client
            await self.session.start()
            self.logger.info("Bot started successfully")
            await self.session.run_until_disconnected()

        except Exception as e:
            self.logger.error(f"Error starting bot: {str(e)}", exc_info=True)
            raise